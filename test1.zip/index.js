var connexMain = connexMain || {};

connexMain = (function() {
    var start = function() {
        window.addEventListener('DOMContentLoaded', function() {
             var logoText =
                     "\r\n------------------------------------------------------------------------------------\r\n"+
                     "  ,ad8888ba,   ,ad8888ba,   888b      88 888b      88 88888888888 8b        d8\r\n"+
                     " d8\"'    `\"8b d8\"'    `\"8b  8888b     88 8888b     88 88           Y8,    ,8P \r\n"+
                     "d8'          d8'        `8b 88 `8b    88 88 `8b    88 88            `8b  d8'  '\r\n"+
                     "88           88          88 88  `8b   88 88  `8b   88 88aaaaa         Y88P    \r\n"+
                     "88           88          88 88   `8b  88 88   `8b  88 88\"\"\"\"\"         d88b    \r\n"+
                     "Y8,          Y8,        ,8P 88    `8b 88 88    `8b 88 88            ,8P  Y8,  \r\n"+
                     " Y8a.    .a8P Y8a.    .a8P  88     `8888 88     `8888 88           d8'    `8b \r\n"+
                     "  `\"Y8888Y\"'   `\"Y8888Y\"'   88      `888 88      `888 88888888888 8P        Y8\r\n"+
                     "\r\n------------------------------------------------------------------------------------\r\n"+
                     "                                                                   CREATED BY JIEUN   \r\n"+
                     "                                                                       ver: 1.0   \r\n\r\n";
                 console.log(logoText);


                connexUI.start();

                // EVENT RESIZE
                $(window).on('resize', function () {
                    connexUI.responsiveStart();
                    return false;
                });


        });
    };

    return {
        start: start
    }
})();

