var connexUI = (function($) {
    var jqbarStatus = true;
    var version = -1;
    var ie10Below = false;
    var on = 'on';
    var off = 'off';
    var $nav2Item = $('.nav2 ').find('li');
    var $nav3Item = $('.nav3 ').find('li');
    var $mapNav = $('.mapNav ');
    var $mapNavItem = $mapNav.find('li');
    var $mainNav = $('.main_header > .nav');
    var $body = $("body")
    var currentScrollTop = 0;
    var responsiveResize;
    var navH = $('.sub_nav').outerHeight();

    responsiveResize = {
        windowSizeWidth: $(window).width(),
        navMain: $('#sitemap1').offset().top - navH,
        nav1_1: $('#sitemap1-1').offset().top - navH,
        nav1_2: $('#sitemap1-2').offset().top - navH,
        nav1_3: $('#sitemap1-3').offset().top - navH,
        nav1_4: $('#sitemap1-4').offset().top - navH,
        nav2_1: $('#sitemap2-1').offset().top - navH,
        nav2_2: $('#sitemap2-2').offset().top - navH,
        nav2_3: $('#sitemap2-3').offset().top - navH,
        nav2_4: $('#sitemap2-4').offset().top - navH,
        nav3_1: $('#sitemap3-1').offset().top - navH,
    };



    var removeClassMapNav = function () {
        $mapNavItem.siblings().removeClass(on);
    };
    var removeClassNav2 = function () {
        $nav2Item.siblings().removeClass(on);
    };
    var removeClassNav3 = function () {
        $nav3Item.siblings().removeClass(on);
    };

    // 브라우저 체크
    var checkIe10Below = function() {
        if (navigator.appName == "Microsoft Internet Explorer" && navigator.userAgent.toLowerCase().indexOf("msie") != -1  && new RegExp("MSIE ([0-9]{1,}[\./0-9]{0,})").exec(navigator.userAgent) != null) {
            version = parseInt(RegExp.$1);
        }
        console.log('IE 9 or 10 : ', version)
        if(version === 10 || version === 9) ie10Below = true;
    };

    // sitemap
    var visibleSitemap = function () {
        $('.btn_sitemap').on('click', function () {
            $('.sitemap').show()
        });

        $('.btn_close').on('click', function () {
            $('.sitemap').hide()
        });

        $('.sitemap a').on('click', function () {
            $('.btn_close').trigger('click');
        });
    };

    // 숫자 카운팅 모션
    var counterMotion = function () {
        $('.counter_').counterUp({
            delay: 10,
            time: 1000
        });
    }
    
    $('.pasing_current').on('beforeChange', function(event, slick, currentSlide, nextSlide) {
            $('.pasing_title').find('li').siblings().removeClass('on');
            $('.pasing_title').find('li').eq(nextSlide).addClass('on');
            console.log(nextSlide);
    });


    // header top에 붙는 모션
    var carryHeder = function () {
        // header 모션 1
        var sticky = new Waypoint.Sticky({
            element: $('.basic-sticky-example')[0]
        });
        // header 모션 2
        var sticky = new Waypoint.Sticky({
            element: $('.basic-sticky-example')[1]
        });
        // header 모션 3
        var sticky = new Waypoint.Sticky({
            element: $('.basic-sticky-example')[2]
        });
    }

    // top 버튼
    var moveTop = function () {
        // back-to-top
        $('#back-to-top').on('click', function (e) {
            e.preventDefault();
            $('html,body').animate({
                scrollTop: 0
            }, 100);
        });
    };

    // 차트
    var motionJqbar = function() {
        $('.content2_txt_area').on('classChanged', function () {
            $('#bar-1').jqbar({ label: '2017', barColor: '#132d63', value: 50, orientation: 'v' });
            $('#bar-2').jqbar({ label: '2018', barColor: '#132d63', value: 55, orientation: 'v' });
            $('#bar-3').jqbar({ label: '2019', barColor: '#132d63', value: 80, orientation: 'v' });
            $('#bar-4').jqbar({ label: '2017', barColor: '#ff8213', value: 35, orientation: 'v' });
            $('#bar-5').jqbar({ label: '2018', barColor: '#ff8213', value: 35, orientation: 'v' });
            $('#bar-6').jqbar({ label: '2019', barColor: '#ff8213', value: 45, orientation: 'v' });
            jqbarStatus = false;
        }).on('jqbarDestroyed', function () {
            $('#bar-1').destroyed();
            $('#bar-2').destroyed();
            $('#bar-3').destroyed();
            $('#bar-4').destroyed();
            $('#bar-5').destroyed();
            $('#bar-6').destroyed();
            jqbarStatus = true;
        });
    };

    // content6 슬라이드 탭
    var slideTab = function() {
        $('.slide_tab_comm').on('click', function(){
            $(this).addClass(on);
            $(this).siblings().removeClass(on);
            console.log('idx', $(this).index())
        });
    }

    /**
     * 기본적으로 사용할 수 있는 탭
     * @param ele : 클릭한 a링크값 (탭 타이틀)
     * @param target : 탭 내용을 전체 감싼 div값
     * @param opt : tab 안에 slick 사용할 경우만 값을 넣어준다.
     */
    var tabClick = function(ele, target, opt) {
        $(ele).on('click', function(){
            var $tabClick = $(this).closest('.tab'); // 전체 컨텐츠에는 .tab 클래스값을 준다.
            var idx = $tabClick.find(ele).index(this);

            console.log('idx:', idx);

            var _parents = $(this).closest("li");
            var _children = $tabClick.find(target).children().eq(idx);
            var on = 'on';

            if(!_parents.hasClass(on)){
                _parents.addClass(on);
                _parents.siblings().removeClass(on);
                _children.addClass(on);
                _children.siblings().removeClass(on);
            };

            // tab안에 slick이 있을경우 opt값에 슬릭 클래스 넣어준다.
            if(opt) {
                if( $tabClick.find('.slick-slider').size() > 0) {
                    $(opt).slick('setPosition');
                }
            }

            return false;
        });
    };


    /**
     * 여기부터는 스크롤 이벤트
     * */
    // 역스크롤일때 최상 메뉴 보이기
    var upScroll = function() {
        console.log('>>> windowSizeWidth' , responsiveResize.windowSizeWidth);
        if(responsiveResize.windowSizeWidth && responsiveResize.windowSizeWidth > 1024) {
            // 1024 미만에서는 적용 안하기
            if (currentScrollTop !== $(window).scrollTop()) {
                if ($(window).scrollTop() < $mainNav.height()) {
                    $body.removeClass("scroll_up scroll_down")
                } else {
                    //console.log($(window).scrollTop(), currentScrollTop)
                    if ( (currentScrollTop < $(window).scrollTop()) && (currentScrollTop !== $(window).scrollTop()) ) {
                        $body.addClass("scroll_down").removeClass("scroll_up")
                    } else {
                        $body.addClass("scroll_up").removeClass("scroll_down")
                    }
                }
                currentScrollTop = $(window).scrollTop();
            }
        } else {
            $body.removeClass("scroll_up scroll_down");
        }
    };

    // mapNav scroll
    var mapNavScroll = function() {
        if($(window).scrollTop() > responsiveResize.nav3_1) {
            removeClassMapNav();
            $mapNavItem.eq(3).addClass(on);
        } else if($(window).scrollTop() > responsiveResize.nav2_1) {
            removeClassMapNav();
            $mapNavItem.eq(2).addClass(on);
        } else if($(window).scrollTop() > responsiveResize.nav1_1) {
            removeClassMapNav();
            $mapNavItem.eq(1).addClass(on);
            $mapNav.removeClass('light');
        } else if($(window).scrollTop() > responsiveResize.navMain) {
            removeClassMapNav();
            $mapNavItem.eq(0).addClass(on);
            $mapNav.addClass('light');
        };
    };

    // main_header scroll
    var mainHeaderScroll = function() {
        if($(window).scrollTop() < $('.main_header .nav').height()) {
            $('.main_header').removeClass(off);
        } else {
            $('.main_header').addClass(off);
        }
    };

    // sub_header active
    var subHeaderScroll = function() {
        if($(window).scrollTop() > responsiveResize.nav2_4) {
            removeClassNav3();
            $nav3Item.eq(3).addClass(on);
        } else if($(window).scrollTop() > responsiveResize.nav2_3) {
            removeClassNav3();
            $nav3Item.eq(2).addClass(on);
        } else if($(window).scrollTop() > responsiveResize.nav2_2) {
            removeClassNav3();
            $nav3Item.eq(1).addClass(on);
        } else if($(window).scrollTop() > responsiveResize.nav2_1) {
            removeClassNav3();
            $nav3Item.eq(0).addClass(on);
        } else if($(window).scrollTop() > responsiveResize.nav1_4) {
            removeClassNav2();
            $nav2Item.eq(3).addClass(on);
        } else if($(window).scrollTop() > responsiveResize.nav1_3) {
            removeClassNav2();
            $nav2Item.eq(2).addClass(on);
        } else if($(window).scrollTop() > responsiveResize.nav1_2) {
            removeClassNav2();
            $nav2Item.eq(1).addClass(on);
        } else if($(window).scrollTop() > responsiveResize.nav1_1) {
            removeClassNav2();
            $nav2Item.eq(0).addClass(on);
        };
    }

    // 차트
    var scrollJqbarReset = function() {
        if(jqbarStatus) {
            if($('.content2_txt_area').hasClass('aos-animate')) {
                $('.content2_txt_area').trigger('classChanged');
            }
        } else {
            if(!$('.content2_txt_area').hasClass('aos-animate')) {
                $('.content2_txt_area').trigger('jqbarDestroyed');
            }
        }
    };


    // START >>>>>>>
    var start = function () {
        $(document).ready(function() {

            console.log('start >>> ', responsiveResize.windowSizeWidth);

            checkIe10Below();
            visibleSitemap();
            carryHeder();
            moveTop();
            slideTab();
            mainHeaderScroll();

            // pasing slick
            $('.pasing_current').slick();

            // content7 탭
            tabClick('.tab_title', '.tab_con');

            // EVENT SCROLL
            $(document).on('scroll', function () {
                upScroll();
                mapNavScroll();
                mainHeaderScroll();
                subHeaderScroll();
                scrollJqbarReset();
            });

            // ie10 이하는 적용 안되는 모션들
            if (!ie10Below) {
                counterMotion();
                // 연혁
                AOS.init();

                motionJqbar();
            }
        });
    };

    var responsiveStart = function () {
        $(document).ready(function() {
            var navH = $('.sub_nav').outerHeight();

            responsiveResize = {
                windowSizeWidth: $(window).width(),
                navMain: $('#sitemap1').offset().top - navH,
                nav1_1: $('#sitemap1-1').offset().top - navH,
                nav1_2: $('#sitemap1-2').offset().top - navH,
                nav1_3: $('#sitemap1-3').offset().top - navH,
                nav1_4: $('#sitemap1-4').offset().top - navH,
                nav2_1: $('#sitemap2-1').offset().top - navH,
                nav2_2: $('#sitemap2-2').offset().top - navH,
                nav2_3: $('#sitemap2-3').offset().top - navH,
                nav2_4: $('#sitemap2-4').offset().top - navH,
                nav3_1: $('#sitemap3-1').offset().top - navH,
            };

            console.log('responsiveStart >>> ', responsiveResize.windowSizeWidth);

            // EVENT SCROLL
            $(document).on('scroll', function () {
                upScroll();
                mapNavScroll();
                mainHeaderScroll();
                subHeaderScroll();
                scrollJqbarReset();
            });
        });
    };

    return {
        start : start,
        responsiveStart : responsiveStart
    }

})(jQuery);

